# Topic 13 — State of the Art in High-Level Synthesis

**Advanced Hardware Engineering | WS 2026/27**  
**Team:** Christian, Rio, Seam, Sharjil  
**Advisor:** Prof. Dr.-Ing. Ali Hayek

## Project objective
Write ONE coherent, critical 6–8-page IEEE-format research paper on the state of the art in HLS: tool comparisons, loop unrolling/pipelining/dataflow, quality of results, and MLIR/CIRCT. The team will decide later whether to include a small benchmark, paper replication, or demonstration from the separate FPGA project. **No experiment is currently required in our internal plan.**

### Proposed research question (approve by 2 Nov)
> How do current HLS tools and emerging compiler infrastructures differ in their optimization capabilities and quality-of-results trade-offs for FPGA design?

## Official milestones
| Deadline | University deliverable |
|---|---|
| 29 Oct 2026 | Team and topic selection |
| 05 Nov 2026 | Research question, outline, >=10 sources |
| 19 Nov 2026 | First paper draft, major figures, references |
| 03 Dec 2026 | Peer review and polishing |
| 31 Dec 2026 | Final 6–8 page IEEE-format PDF |
| 07 Jan 2027 | 20-minute presentation plus discussion |

## Team ownership (proposed; confirm in kickoff)
| Member | Primary subject | Owns first draft of | Reviewer of |
|---|---|---|---|
| Christian | HLS optimization techniques and coordination | `sections/04_optimizations.tex` | Sharjil's section |
| Rio | Tool landscape and comparison | `sections/03_tools.tex` | Christian's section |
| Seam | QoR metrics, benchmarking methodology, evidence | `sections/05_qor.tex` | Rio's section |
| Sharjil | MLIR, CIRCT, compiler trends | `sections/06_compilers.tex` | Seam's section |

**Shared:** `01_introduction.tex`, `02_background.tex`, `07_discussion.tex`, `08_conclusion.tex`, research question, abstract, references, slides. Christian coordinates *process*; each owner remains accountable for their task and deadline. Rotating weekly integration lead avoids depending on one person.

## First week — minimum viable deliverables
- **29 Oct:** confirm team, topic, role owners, communication channel and meeting time.
- **30 Oct:** every member can open this project, edit their own section, and add a BibTeX entry; confirm in chat.
- **1 Nov:** each person logs 3–4 candidate sources in `literature_tracker.csv`, with links and relevance (target >=12 unique candidates).
- **2 Nov:** team agrees on ONE research question, scope, and table of contents.
- **3 Nov:** each owner submits a paragraph-level section outline, claims they expect to support, and one proposed figure/table.
- **4 Nov:** 20-minute review; reconcile duplicate literature, select >=10 suitable sources and submit outline.
- **5 Nov:** official milestone 2.

## Suggested internal gates
- **12 Nov:** every owner has a readable draft of their main technical section, with citations and at least one analytical comparison.
- **16 Nov:** integrated whole-paper v0.1 with introduction, discussion, conclusion and figure placeholders.
- **18 Nov:** internal review/fixes complete.
- **19 Nov:** first draft milestone.
- **29 Nov:** cross-review comments returned.
- **02 Dec:** revisions integrated.
- **03 Dec:** peer review milestone.
- **16 Dec:** technically complete final candidate.
- **23 Dec:** citation, formatting, originality and QA checks.
- **28 Dec:** freeze submission-ready PDF.
- **31 Dec:** official paper submission.
- **05 Jan:** presentation rehearsal.
- **07 Jan:** presentation.

## Simple collaboration workflow
1. Create a GitHub issue using `TASK_TEMPLATE.md` for each deliverable: one owner, due date, and review partner.
2. Change issue status **To do -> In progress -> In review -> Done**. A task is **Done** only when an actual file/section/table has been delivered and checked.
3. Work in your own `.tex` section. Avoid simultaneous edits to `main.tex` or shared BibTeX without warning teammates.
4. Add each scholarly reference to `references.bib`; record relevance, evidence, and limits in `literature_tracker.csv`. Verify exact metadata before final submission.
5. Open a pull request or link changed lines/file in chat for the assigned reviewer. Reviewer either approves or requests specific corrections.
6. Weekly 20-minute check-in: completed, next, blocked. Update board **before** meeting; no need for daily chasing.
7. The week's rotating integration lead checks Overleaf compilation, bibliography and missing sections. Report blockers promptly, not at deadline.

## Recommended file ownership
- Christian: optimization section and task board setup.
- Rio: tool comparison section and evidence table.
- Seam: QoR comparison and literature-based evaluation plan.
- Sharjil: MLIR/CIRCT and compiler evolution.
- Integration lead: rotates weekly (week 1 Christian; week 2 Rio; week 3 Seam; week 4 Sharjil).

## Research quality rules
- Distinguish **claims from evidence**; every numerical claim must identify a source and experimental conditions.
- Do **not** compare LUT/DSP/clock/latency numbers across papers as if they were same-device benchmarks unless the methodology supports it.
- Separate results reported by papers from any team measurements.
- At least 15 **verified** references in the final paper, IEEE style. Use published sources; vendor documentation can support tool facts but should not be the entire evidence base.
- Cite any reused figure; redraw with attribution where appropriate. Declare AI assistance according to university policy.
- Prefer analytical comparisons, limitations and trade-offs over long generic FPGA introductions.

## Work setup
**Simplest:** import this ZIP in Overleaf and share editor access with all 4 members; track tasks in GitHub Issues/Projects. **Optional:** connect Overleaf to Git/GitHub if supported by your plan. GitHub issue board and Overleaf are separate unless integrated explicitly.

**To compile:** select `main.tex`, pdfLaTeX, and BibTeX if asked. `IEEEtran` should be present in Overleaf. Citations will remain empty until real sources are added to `references.bib`.
