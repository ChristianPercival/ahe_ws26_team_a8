Place original or properly attributed figures here. Keep source and permission/attribution info in literature tracker or captions. Prefer PDF/PNG images of readable quality.
