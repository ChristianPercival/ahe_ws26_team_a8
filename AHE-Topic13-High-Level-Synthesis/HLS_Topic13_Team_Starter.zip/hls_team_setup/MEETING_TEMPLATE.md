# HLS weekly check-in — YYYY-MM-DD (20 minutes)

**Present:**

| Member | Delivered since last check | Next deliverable + date | Blocker / help needed |
|---|---|---|---|
| Christian | | | |
| Rio | | | |
| Seam | | | |
| Sharjil | | | |

**Decisions made (with owners):**

**Overdue tasks and recovery plan:**

**Next meeting:**
