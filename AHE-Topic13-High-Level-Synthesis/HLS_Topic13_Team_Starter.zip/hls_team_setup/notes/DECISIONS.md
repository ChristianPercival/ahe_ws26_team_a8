# Decision log

| Date | Decision | Reason | Agreed by |
|---|---|---|---|
| 2026-10-28 | Initial plan: focus on research paper; whether to run a demonstration will be decided later. | Separate FPGA project requirements are not known yet. | Pending team confirmation |
