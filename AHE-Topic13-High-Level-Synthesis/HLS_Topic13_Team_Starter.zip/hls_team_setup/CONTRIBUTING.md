# Contribution and review agreement

**Ownership:** Your named section is your responsibility; if blocked, flag the issue within 24 hours. Coordination does not transfer ownership to Christian.

**Deliver a section:**
- Is it on-topic and within a realistic space budget (6–8 pages TOTAL)?
- Does it answer part of the research question?
- Does it compare alternatives/trade-offs, rather than only describe?
- Are facts and graphics correctly cited?
- Are all metrics and comparisons qualified by device/tool/version/methodology?
- Did you verify citations against actual papers?
- Did it compile without errors (or did you flag an issue)?

**Review another member:** comment on technical correctness, evidence, clarity, duplication and length. Approval requires concrete deliverables, not just an update saying 'done'.

**Decision rule:** Scope and final argument are agreed in a team meeting. If a decision cannot wait, record the proposed decision in an issue and allow 24 hours for objections. Escalate substantial disagreements to a short team call.

**Travel-friendly:** All writing, literature logging, figures, issue updates and review should work remotely. Experiments are an optional future team decision and need a separate owner, hardware/tool access check and scope agreement.
