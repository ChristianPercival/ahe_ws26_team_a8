# [Deliverable-oriented task title]
**Owner:**  
**Reviewer:**  
**Due (internal):**  
**Milestone:**  
**Status:** To do / In progress / In review / Done

## Objective
What question must this task answer?

## Deliverable
Exact file(s), table(s), subsection(s), or research record(s) to submit.

## Acceptance criteria
- [ ] Research claims have verified citations
- [ ] Relevant comparisons / limitations are included
- [ ] Text is integrated in the common paper style
- [ ] Reviewer has checked and approved

## Dependencies or blockers
None / specify.
